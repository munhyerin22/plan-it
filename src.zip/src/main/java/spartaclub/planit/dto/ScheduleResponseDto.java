package spartaclub.planit.dto;

import lombok.Getter;
import java.time.LocalDateTime;

@Getter
public class ScheduleResponseDto(Long id, String title, String content, String name, LocalDateTime createdAt, LocalDateTime updatedAt) {
    private final Long id;
    private final String title;
    private final String content;
    private final String name;
    private final LocalDateTime createdAt;
    private final LocalDateTime updatedAt;
}

    public ScheduleResponseDto(Long id, String title, String content, String name) {
        this.id = id;
        this.title = title;
        this.content = content;
        this.name = name;
    }
}
