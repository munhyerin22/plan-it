package spartaclub.planit.service;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import spartaclub.planit.dto.GetOneScheduleResponse;
import spartaclub.planit.dto.ScheduleRequestDto;
import spartaclub.planit.dto.ScheduleResponseDto;
import spartaclub.planit.entity.Schedule;
import spartaclub.planit.repository.ScheduleRepository;

import java.util.ArrayList;
import java.util.List;
//import spartaclub.planit.repository.ScheduleRepository;


@Service
@RequiredArgsConstructor
public class ScheduleService {
    private final ScheduleRepository scheduleRepository;

    //저장
    @Transactional
    public ScheduleResponseDto create(ScheduleRequestDto request){
        Schedule schedule = new Schedule(
                request.getTitle(),
                request.getContent(),
                request.getName(),
                request.getPassword()
        );


        Schedule createdSchedule = scheduleRepository.save(schedule);

        return new GetOneScheduleResponse(
                schedule.getId(),
                schedule.getTitle(),
                schedule.getContent(),
                schedule.getName()
        );
    }

    // 단 건 조회
    @Transactional(readOnly = true)
    public GetOneScheduleResponse getOne(Long scheduleId) {
        Schedule schedule = scheduleRepository.findById(scheduleId).orElseThrow(
                () -> new IllegalStateException("없음")
        );
        return new GetOneScheduleResponse(
                schedule.getId(),
                schedule.getTitle(),
                schedule.getContent(),
                schedule.getName()
        );
    }

    //다 건 조회
    @Transactional(readOnly = true)
    public List<GetOneScheduleResponse> getAll(String name){
        List<Schedule> schedules = scheduleRepository.findAll();

        List<GetOneScheduleResponse> dtos = new ArrayList<>();
        for(Schedule schedule : schedules){
            GetOneScheduleResponse dto = new GetOneScheduleResponse(
                    schedule.getId(),
                    schedule.getTitle(),
                    schedule.getContent(),
                    schedule.getName()
            );
            dtos.add(dto);
        }
        return dtos;

    }

}

